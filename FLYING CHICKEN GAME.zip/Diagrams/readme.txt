-You can play w,a,s,d or pg_up,pg_down,pg_right,pg_left
-Chicken can move right,left,up,down
-If you press space,chicken shots with golden egg from its mouth
-If chicken collides with cat,cat eats chicken and game over
-If chicken hit the targets with golden egg,chicken's point will increase
-During level 2,if chicken hit cat with golden egg,chicken's point decrease.If chicken's point less than 0 game over again.
-To run the program,you have to run ekran.java



MEMBERS OF GROUP
  -19290340 SEMA YAPRAKLI
  -19290338 ERALP ÜNVER